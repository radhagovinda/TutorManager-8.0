<TITLE>Untitled Document</TITLE><STYLE type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
.style1 {
	color: #FFFFFF;
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
	font-size: 12px;
}
.style2 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #FFFFFF;}
-->
</STYLE>  <TITLE>Untitled Document</TITLE> 

 
<TABLE width="100%" border="0" cellspacing="0" cellpadding="10">
  <TBODY>
  <TR>
    <TD height="80" 
      background="images/bg.png"><SPAN 
      class="style1">© </SPAN><SPAN 
      class="style2">ShikshaSutram</SPAN></TD></TR></TBODY></TABLE>