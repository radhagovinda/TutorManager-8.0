<TITLE>Untitled Document</TITLE><STYLE type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-image: url(images/bg-gray.png);
}
.style1 {
	font-size: 24px;
	font-weight: bold;
	font-family: Georgia, "Times New Roman", Times, serif;
	color: #FFFFFF;
}
.style2 {
	font-size: 16px;
	font-style: italic;
}
.style3 {
	font-size: 36px;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
-->
</STYLE>  <TITLE>Untitled Document</TITLE> 

 
<TABLE width="100%" border="0" cellspacing="0" cellpadding="0">
  <TBODY>
  <TR>
    <TD height="10" background="images/header-w.png"><IMG width="32" height="10" 
      alt="" src=""></TD>   </TR>
  <TR>
    <TD background="images/bg.png">
      <TABLE width="100%" border="0" cellspacing="5" cellpadding="10">
        <TBODY>
        <TR>
          <TD height="100"><SPAN class="style1"><SPAN class="style3"><IMG 
            width="50" height="32" alt="" src="">Tuition Manager</SPAN><BR><SPAN 
            class="style2"><SPAN class="style3"><IMG width="50" height="32" alt="" 
            src=""></SPAN>Manage your students/Attendance/Exams more 
            efficiently</SPAN></SPAN></TD></TR>
        <TR>
          <TD><A href="menu.php"><SPAN class="style3"><IMG width="50" height="32" 
            alt="" src=""></SPAN><IMG width="68" height="64" align="absmiddle" src="images/home-65.png" border="0"></A><A href="http://pradipmathsir.eduz.in"><FONT 
            color="#ffffff"><B>Go to Main 
    Site</B></FONT></A></TD></TR></TBODY></TABLE></TD></TR>
  <TR>
    <TD height="10" background="images/header-w.png"><IMG width="32" height="10" 
      alt="" src=""></TD></TR></TBODY></TABLE>